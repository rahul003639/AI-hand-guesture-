#!/bin/bash
# auto_calibrate.sh - Illustrative script
echo "Collecting 5 samples per gesture..."
# In practice, call Python data collection script in calibration mode to store personal_data.npz
python3 desktop_python/collect_gestures.py
echo "Run personalization (few-shot fine-tune) ..."
python3 ai_features/personalize.py
echo "Calibration complete. Copy gesture_model_personal.tflite to mobile app assets and restart app."

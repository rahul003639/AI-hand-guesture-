# gesture_to_action.py
# Convert detected gestures (single or short sequences) into higher-level actions.
# This file provides:
# - rule_based_mapper: local deterministic mapping
# - llm_mapper_stub: shows how to call a cloud LLM safely (placeholder only)
import time, json

# Example rule-based mapper
def rule_based_mapper(sequence):
    # sequence: list of (gesture_label, timestamp) pairs, latest last
    labels = [g for g,t in sequence]
    # Simple heuristics:
    if len(labels) >= 2 and labels[-2:] == ['point','pinch']:
        return ('click', {'type':'left'})
    if labels[-1] == 'thumbs_up':
        return ('accept_call', {})
    if labels[-1] == 'thumbs_down':
        return ('reject_call', {})
    if labels[-1] == 'open_palm':
        return ('pause_media', {})
    if labels[-1] == 'fist':
        return ('play_media', {})
    # default: no action
    return (None, {})

# Example LLM integration stub (DO NOT send video or raw PII). Use this to convert complex sequences to commands.
def llm_mapper_stub(sequence, context_info=None):
    # WARNING: This is a stub showing the flow. Implement actual API calls securely if you wish.
    # Build a concise prompt describing the recent gesture sequence and current app context.
    prompt = f"Translate the gesture sequence to a single action. Sequence: {sequence}. Context: {context_info or {}}"
    print('LLM prompt (send this securely to your LLM backend):', prompt)
    # Example safe response parsing (pretend LLM returns JSON)
    # resp = call_your_llm_api(prompt)
    # action = parse(resp)
    # return action
    return (None, {})

# Example usage
if __name__ == '__main__':
    seq = [('point', time.time()-1.2), ('pinch', time.time())]
    action, meta = rule_based_mapper(seq)
    print('Mapped action:', action, meta)

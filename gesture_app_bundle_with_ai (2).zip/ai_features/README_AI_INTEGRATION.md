AI Integration Notes (on-device vs cloud)
-----------------------------------------

On-device advantages:
- Privacy: no camera frames leave the device.
- Low-latency: models run locally for immediate response.
- Offline availability.

On-device disadvantages:
- Limited model size and compute on mobile devices.
- Personalization must be efficient (few-shot, small head fine-tuning) or use on-device adaptation techniques.

Cloud advantages:
- Use larger models (LLMs) for complex mapping (gesture sequence -> semantic command).
- Easier to maintain one central mapping logic and update it frequently.

Cloud disadvantages / cautions:
- Privacy risk: NEVER send raw camera frames to the cloud without explicit, informed consent. Strip PII and send only abstracted data (gesture labels, timestamps, app context).
- Latency and reliability depend on network.
- Cost: LLM calls are not free.

Recommended hybrid architecture:
- Do landmark extraction and gesture classification on-device (MediaPipe + TFLite).
- Send only the recent gesture sequence (labels + timestamps) and minimal context (active app name, user settings) to a secure cloud backend if a complex interpretation is required.
- Server returns a single action JSON (e.g., {"action":"copy_text","args":{...}}).

Security & privacy checklist:
- Always show a camera indicator when camera is active.
- Provide a privacy screen explaining what is sent to the cloud and store user consent.
- Rate-limit cloud calls and cache responses for repeated sequences.

Performance tips:
- Quantize TFLite models if possible (post-training quantization).
- Use NNAPI (Android) / CoreML (iOS) delegates for acceleration.
- For temporal models, use small sequence lengths (e.g., 8-16 frames) and low frame-rate (10-15 FPS) to balance latency and accuracy.

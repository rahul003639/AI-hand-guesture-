AI Features added to GestureControlApp
--------------------------------------

This folder contains example AI enhancements you can integrate into the project. These are runnable/example scripts and design notes for adding:
1. Temporal gesture models (LSTM/1D-CNN) for dynamic gestures (swipes, waves).
2. Personalization / transfer learning utilities to adapt the classifier to a user's hand and environment with a few-shot update.
3. Gesture-to-action mapping module that converts gesture sequences into higher-level commands using rules or a small on-device model. Optionally shows how to call a cloud LLM safely.
4. Smart context-awareness: combining hand pose + screen context (active app) to pick the most likely action.
5. Auto-calibration script that collects a few samples and fine-tunes the TFLite model (illustrative).

Files:
- train_temporal.py        : Train a simple LSTM on sequences of landmark frames.
- personalize.py          : Few-shot personalization script to fine-tune a Keras model.
- gesture_to_action.py    : Maps detected gestures (including short sequences) to actions. Contains a local rule-based mapper and example cloud-LLM stub.
- auto_calibrate.sh       : Bash script (illustrative) to collect samples and run personalization pipeline.
- README_AI_INTEGRATION.md: Integration notes (on-device vs cloud tradeoffs, privacy, performance).

IMPORTANT: These examples are illustrations. Converting trained models to quantized TFLite and integrating into mobile apps requires additional steps (covered in README_AI_INTEGRATION.md).

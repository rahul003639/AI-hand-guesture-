# personalize.py
# Few-shot personalization: load base Keras model, collect a few samples per gesture, fine-tune last layers.
import numpy as np
import os, json
from tensorflow.keras.models import load_model
from tensorflow.keras import layers, models
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import LabelEncoder

BASE_MODEL = 'gesture_model.h5'  # pre-trained base model (dense input model)
PERSONAL_DATA = 'personal_data.npz'  # expected to contain X and y arrays

def load_personal_data(path=PERSONAL_DATA):
    if not os.path.exists(path):
        raise FileNotFoundError('Collect personal_data.npz first (collect few samples per gesture).')
    data = np.load(path)
    return data['X'], data['y']

def fine_tune(base_model_path=BASE_MODEL, personal_data_path=PERSONAL_DATA, epochs=10, lr=1e-4):
    X, y = load_personal_data(personal_data_path)
    le = LabelEncoder(); y_enc = le.fit_transform(y)
    base = load_model(base_model_path)
    # Freeze earlier layers, recompile small head for personalization.
    for layer in base.layers[:-2]:
        layer.trainable = False
    x = base.layers[-2].output
    new_out = layers.Dense(64, activation='relu')(x)
    new_out = layers.Dense(len(np.unique(y_enc)), activation='softmax')(new_out)
    model = models.Model(inputs=base.input, outputs=new_out)
    model.compile(optimizer=Adam(lr), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    model.fit(X, y_enc, epochs=epochs, batch_size=8, validation_split=0.2)
    model.save('gesture_model_personal.h5')
    # Convert to TFLite for mobile deployment (optional)
    try:
        import tensorflow as tf
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        tflite_model = converter.convert()
        open('gesture_model_personal.tflite','wb').write(tflite_model)
        print('Saved gesture_model_personal.tflite')
    except Exception as e:
        print('TFLite conversion skipped or failed:', e)

if __name__ == '__main__':
    fine_tune()

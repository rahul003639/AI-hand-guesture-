# train_temporal.py
# Train a temporal model (LSTM) on sequences of MediaPipe landmarks.
# Input: sequences of shape (seq_len, 63) where 63 = 21 landmarks * (x,y,z)
# Output: gesture class probabilities.
import numpy as np
from tensorflow.keras import models, layers
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# This script expects a dataset of sequences saved as numpy arrays.
# Example data prep: collect sequences by recording short clips per gesture and stacking frames.
# For demo, we will synthesize simple data if no real dataset is available.

def synthesize_data(num_gestures=6, samples_per_gesture=200, seq_len=10, feat_dim=63):
    X = np.random.randn(num_gestures * samples_per_gesture, seq_len, feat_dim).astype('float32')
    y = np.repeat(np.arange(num_gestures), samples_per_gesture)
    return X, y

def load_data(path=None):
    # Replace with real loader for recorded sequences
    return synthesize_data()

if __name__ == '__main__':
    X, y = load_data()
    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    Xtr, Xte, ytr, yte = train_test_split(X, y_enc, test_size=0.15, random_state=42)
    model = models.Sequential([
        layers.Input(shape=(Xtr.shape[1], Xtr.shape[2])),
        layers.Masking(mask_value=0.0),
        layers.LSTM(128, return_sequences=False),
        layers.Dropout(0.3),
        layers.Dense(64, activation='relu'),
        layers.Dense(len(np.unique(ytr)), activation='softmax')
    ])
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    model.summary()
    model.fit(Xtr, ytr, epochs=25, batch_size=32, validation_data=(Xte, yte))
    model.save('temporal_gesture_model.h5')
    # Convert to TFLite if desired
    try:
        import tensorflow as tf
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        tflite_model = converter.convert()
        open('temporal_gesture_model.tflite','wb').write(tflite_model)
        print('Saved temporal_gesture_model.tflite')
    except Exception as e:
        print('TFLite conversion skipped or failed:', e)

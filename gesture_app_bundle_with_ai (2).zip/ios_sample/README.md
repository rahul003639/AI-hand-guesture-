iOS Sample (Swift) - Overview
Files included:
- ViewController.swift (sample showing camera capture + placeholder for MediaPipe/TFLite integration)
- Info.plist note: request camera permission in project settings
- README contains steps

Follow steps:
1. Use MediaPipe iOS or TFLite + hand detection model.
2. Put gesture_model.tflite in the app bundle and initialize TFLite interpreter.
3. Build with Xcode on a Mac.

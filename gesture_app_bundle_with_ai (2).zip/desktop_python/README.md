Desktop Python App - MediaPipe + TFLite example
Files:
- collect_gestures.py : collect landmark vectors using MediaPipe and save NPZ
- train.py : simple trainer (Keras) to create a model.h5 then convert to TFLite
- infer_demo.py : runtime demo that loads TFLite model and runs inference on webcam frames
- requirements.txt : pip packages

Run:
1. pip install -r requirements.txt
2. python collect_gestures.py
3. python train.py
4. python infer_demo.py

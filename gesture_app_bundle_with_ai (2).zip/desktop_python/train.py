# train.py - simple trainer (requires TensorFlow)
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from tensorflow.keras import models, layers
data = np.load('gesture_data/gestures.npz')
X, y = data['X'], data['y']
le = LabelEncoder()
y_enc = le.fit_transform(y)
sc = StandardScaler(); Xs = sc.fit_transform(X)
model = models.Sequential([
    layers.Input(shape=(Xs.shape[1],)),
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.3),
    layers.Dense(64, activation='relu'),
    layers.Dense(len(set(y_enc)), activation='softmax'),
])
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.fit(Xs, y_enc, epochs=20, batch_size=32, validation_split=0.15)
model.save('gesture_model.h5')
# Convert to TFLite
import tensorflow as tf
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()
open('gesture_model.tflite','wb').write(tflite_model)
print('Saved gesture_model.h5 and gesture_model.tflite')

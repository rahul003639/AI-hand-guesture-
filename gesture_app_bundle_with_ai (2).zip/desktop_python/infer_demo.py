# infer_demo.py - runtime using MediaPipe landmarks + TensorFlow Lite
import cv2, mediapipe as mp, numpy as np
try:
    import tflite_runtime.interpreter as tflite
except:
    import tensorflow as tf
    tflite = tf.lite
MODEL = 'gesture_model.tflite'
labels = ['open_palm','fist','thumbs_up','thumbs_down','point','pinch']
interpreter = tflite.Interpreter(model_path=MODEL)
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

mp_hands = mp.solutions.hands
cap = cv2.VideoCapture(0)
with mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.6) as hands:
    while True:
        ret,img = cap.read()
        if not ret: break
        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        res = hands.process(rgb)
        if res.multi_hand_landmarks:
            lm = res.multi_hand_landmarks[0]
            coords = []
            for p in lm.landmark:
                coords += [p.x, p.y, p.z]
            inp = np.array(coords, dtype=np.float32).reshape(1,-1)
            # If model expects scaled input, scale externally or use saved scaler.
            interpreter.set_tensor(input_details[0]['index'], inp)
            interpreter.invoke()
            out = interpreter.get_tensor(output_details[0]['index'])
            idx = int(out.argmax())
            conf = float(out[0, idx])
            text = f"{labels[idx]} ({conf:.2f})"
            cv2.putText(img, text, (10,30), cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2)
        cv2.imshow('infer', img)
        if cv2.waitKey(1)&0xFF==27: break
cap.release(); cv2.destroyAllWindows()

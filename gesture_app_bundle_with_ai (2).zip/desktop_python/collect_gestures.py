# collect_gestures.py
import cv2, mediapipe as mp, numpy as np, os, time
mp_hands = mp.solutions.hands
DATA_DIR = "gesture_data"
os.makedirs(DATA_DIR, exist_ok=True)
GESTURES = ["open_palm","fist","thumbs_up","thumbs_down","point","pinch"]
cap = cv2.VideoCapture(0)
with mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.6) as hands:
    samples, labels = [], []
    for gesture in GESTURES:
        print(f"Prepare to record: {gesture}. Press 's' to start.")
        while True:
            ret, img = cap.read()
            if not ret: break
            cv2.putText(img, f"Press 's' to record: {gesture}", (10,30), cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2)
            cv2.imshow("collect", img)
            if cv2.waitKey(1)&0xFF==ord('s'):
                break
        t_end = time.time()+5
        while time.time()<t_end:
            ret,img = cap.read()
            if not ret: break
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            res = hands.process(img_rgb)
            if res.multi_hand_landmarks:
                lm = res.multi_hand_landmarks[0]
                coords = []
                for p in lm.landmark:
                    coords += [p.x, p.y, p.z]
                samples.append(coords); labels.append(gesture)
            cv2.imshow("collect", img)
            if cv2.waitKey(1)&0xFF==27: break
    np.savez_compressed(os.path.join(DATA_DIR,"gestures.npz"), X=np.array(samples), y=np.array(labels))
cap.release(); cv2.destroyAllWindows()
print("Saved data.")

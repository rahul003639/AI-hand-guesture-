GestureControlApp - Multi-platform skeleton
Includes:
- Android: Kotlin + MediaPipe + TFLite integration guidance and sample MainActivity/Kotlin code.
- iOS: Swift + MediaPipe/CoreML/TFLite guidance and sample ViewController.swift code.
- Desktop: Python app (MediaPipe + TensorFlow/TFLite) with infer_demo and data collection scripts.
- models/: placeholder model files (put your trained .tflite or .h5 here).
- LICENSE: MIT

IMPORTANT:
- These are skeleton/example projects and not full buildable OS-specific projects due to size and environment limits.
- Follow the instructions in each platform README to integrate MediaPipe and TensorFlow Lite and to convert models.


## AI Features Added
See ai_features/ for temporal models, personalization, and gesture-to-action mapping examples.

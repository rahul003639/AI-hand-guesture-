Android Sample (Kotlin) - Overview
Files included:
- app/src/main/java/com/example/gesture/MainActivity.kt (sample code showing CameraX + MediaPipe hands + TFLite inference)
- app/src/main/res/layout/activity_main.xml (layout)
- build.gradle (app-level) - minimal placeholders

Follow steps:
1. Add MediaPipe Android AAR or use MediaPipe Tasks API per MediaPipe docs.
2. Add TensorFlow Lite interpreter dependency in build.gradle.
3. Put gesture_model.tflite into app/src/main/assets/
4. Build and run on a device with camera permission.
